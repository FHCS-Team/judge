-- minimal migration for in-memory tests
CREATE TABLE IF NOT EXISTS sample_table (id SERIAL PRIMARY KEY);
